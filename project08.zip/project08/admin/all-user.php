<h1><span class="text-primary" style="font-size:60px"> <i class="fas fa-tachometer-alt"></i> All Users. </span></h1>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user"></i> All User</li>
        </ol>
    </nav>
        <div class="table-responsive">
        <table class="table table-hover table-bordered table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>User Name</th>
                    <th>Photo</th>
                </tr>
            </thead>
            <tbody>
                <?php
                   $show_student= mysqli_query($link, "SELECT * FROM `users`");

                    while($row = mysqli_fetch_assoc($show_student)){
                ?>
                <tr>
                    <td><?php echo ucwords($row['name']); ?> </td>
                    <td><?php echo ucwords($row['email']); ?> </td>
                    <td><?php echo ucwords($row['username']); ?> </td>
                    <td><img style="width:100px; height:100px" src="images/<?php echo $row['photo']; ?>" alt="profile"></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        </div>