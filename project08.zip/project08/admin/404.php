<h1 class="text-danger text-center">404!!!</h1>
<h2 class="text-danger text-center">File not found!</h2>
<div style="text-align: center; margin-bottom: 10px "><img src="images/404.jpg" alt="" width="800px" ></div>