<h1><span class="text-primary" style="font-size:60px"> <i class="fas fa-tachometer-alt"></i> All Students. </span>add new student</h1>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user"></i> All Student</li>
        </ol>
    </nav>
        <div class="table-responsive">
        <table class="table table-hover table-bordered table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Roll</th>
                    <th>City</th>
                    <th>Class</th>
                    <th>Contact</th>
                    <th>Photo</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                   $show_student= mysqli_query($link, "SELECT * FROM `student_info`");

                    while($row = mysqli_fetch_assoc($show_student)){
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo ucwords($row['name']); ?> </td>
                    <td><?php echo $row['roll']; ?></td>
                    <td><?php echo ucwords($row['city']); ?></td>
                    <td><?php echo $row['class']; ?></td>
                    <td><?php echo $row['contact']; ?></td>
                    <td><img style="width:100px; height:100px" src="student-img/<?php echo $row['photo']; ?>" alt="profile"></td>
                    <td>
                        <a class="btn btn-xs btn-warning" style="padding: 10px" href="index.php?page=update-student&id=<?php echo base64_encode($row['id']); ?>"><i class="fas fa-pencil"></i> Edit </a> ||
                        <a class="btn btn-xs btn-danger" href="delete-student.php?id=<?php echo base64_encode($row['id']); ?>"><i class="fas fa-trash-alt"></i> Delete</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        </div>