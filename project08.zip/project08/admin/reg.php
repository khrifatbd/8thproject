<?php
require_once ('dbcon.php');
session_start();

 if(isset($_POST["registion"])){
  $name   = $_POST['name'];
  $email   = $_POST['email'];
  $username   = $_POST['username'];
  $password   = $_POST['password'];

 $photo = explode('.', $_FILES['photo']['name']) ;
 $photo =end( $photo);
  $photo_name = $username.'.'.$photo;

 $input_error = array();



 if(empty($name)){
   $input_error['name'] ="Plz enter your name!";
 }
 if(empty($email)){
   $input_error['email'] ="Plz enter your email!";
 }
 if(empty($username)){
   $input_error['username'] ="Plz enter your username!";
 }
 if(empty($password)){
   $input_error['password'] ="Plz enter your password!";
 }
 if(empty($name)){
   $input_error['name'] ="Plz enter your name!";
 }

if(count($input_error) == 0){
  $email_cheak =mysqli_query($link, "SELECT * FROM `users` WHERE email = '$email'; ");
  if(mysqli_num_rows($email_cheak) == 0){
    $username_cheak =mysqli_query($link, "SELECT * FROM `users` WHERE username = '$username'; ");
    if(mysqli_num_rows($username_cheak) == 0){
      if(strlen($username) >7 ){
        if(strlen($password) >7){
          $password = md5($password);
         $query ="INSERT INTO `users`( `name`, `email`, `username`, `password`, `photo`, `stutas`) VALUES ('$name', '$email', '$username', '$password', '$photo_name', 'inactive')";
          $result = mysqli_query($link, $query);
          if($result){
            $_SESSION['data_insert_seccessfully'] ="Data insert Successfully";
            move_uploaded_file($_FILES['photo']['tmp_name'],'images/'.$photo_name);
            header('location:reg.php');
          }else{
            $_SESSION['data_insert_error'] ="Data does not insert!";
          }


        }else{
          $password_len = "password more then 8 careectar";
        }
      }else{
        $username_errorl = "Username is more than 8 carectar";
      }
    }else{
     $username_error ="This Username already exits";
    }
  }else{
    $email_error = "This email already exits.";
  }

} 






 }

?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet">
    <title>User registion form!</title>
  </head>
  <body>

    <div class="container"><br>
      <h1> User Registion form</h1><br>
      <hr>
      <?php 
        if(isset($_SESSION['data_insert_seccessfully'])){
          echo '<div class="alert alert-success">'. $_SESSION['data_insert_seccessfully'].'</div>';
        }
      ?>
      <?php 
        if(isset($_SESSION['data_insert_error'])){
          echo '<div class="alert alert-danger">'. $_SESSION['data_insert_error'].'</div>';
        }
      ?>
      
      
      <div class="row">
        <div class="col-md-12">
          <form action="" method="POST" enctype="multipart/form-data" class="form-horizontal ">
            <div class="form-group">
              <label for="name" class='form-label'>Name</label>
              <div class="col-sm-4">
                <input type="name" class="form-control " id="name" name="name" value="<?php if(isset($name)){echo $name;} ?>">
              </div>
              <label class="error"><?php if(isset($input_error['name'])){ echo $input_error['name'];} ?> </label>
            </div>
            <div class="form-group">
              <label for="email" class='form-label'>Email</label>
              <div class="col-sm-4">
                <input type="email" class="form-control " id="email" name="email" value="<?php if(isset($email)){echo $email;} ?>">
              </div>
              <label class="error"><?php if(isset($input_error['email'])){ echo $input_error['email'];} ?> </label>
              <label class="error"><?php if(isset($email_error)){ echo $email_error;} ?> </label>
            </div>
            <div class="form-group">
              <label for="username" class='form-label'>Username</label>
              <div class="col-sm-4">
                <input type="text" class="form-control " id="username" name="username"  value="<?php if(isset($username)){echo $username;} ?>" >
              </div>
              <label class="error"><?php if(isset($input_error['username'])){ echo $input_error['username'];} ?> </label>
              <label class="error"><?php if(isset($username_error)){ echo $username_error;} ?> </label>
              <label class="error"><?php if(isset($username_errorl)){ echo $username_errorl;} ?> </label>
            </div>
            <div class="form-group">
              <label for="password" class='form-label'>Password</label>
              <div class="col-sm-4">
                <input type="password" class="form-control " id="password" name="password">
              </div>
              <label class="error"><?php if(isset($input_error['password'])){ echo $input_error['password'];} ?> </label>
              <label class="error"><?php if(isset($password_len)){ echo $password_len;} ?> </label>
            </div>
            <div class="form-group">
              <label for="photo" class='form-label'>Photo</label>
              <div class="col-sm-4">
                <input type="file" class="form-control " id="photo" name="photo">
              </div>
            </div><br>
            <div class="col-sm-4">
              <input type="submit" value="Registion" name="registion" class="btn btn-primary offset-sm-3">
            </div>
          </form>
        </div>
      
      
      
      </div>
      <p>If you have any account? <a href="login.php">LogIn here.</a></p>
      <hr><br>
      <footer>
        <p>copyright khrifat</p>
      </footer>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>