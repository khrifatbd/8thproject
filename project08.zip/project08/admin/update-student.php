<h1><span class="text-primary" style="font-size:60px">  <i class="fas fa-edit"></i></i> </i>Update Student. </span>update a student</h1>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-edit"></i></i> Update Student</li>
        </ol>
    </nav>
<?php
$id = base64_decode($_GET['id']);
$db_data = mysqli_query($link," SELECT * FROM student_info WHERE `id` = '$id'");

$db_row = mysqli_fetch_assoc($db_data);

if(isset($_POST['update-student'])){
    $name = $_POST['name'];
    $roll = $_POST['roll'];
    $city = $_POST['city'];
    $contact = $_POST['contact'];
    $class = $_POST['class'];

    $query = "UPDATE `student_info` SET `name`='$name',`roll`='$roll',`class`='$class',`city`='$city',`contact`='$contact' WHERE `id`='$id' ";
    $result = mysqli_query($link, $query);
     if($result){
         header('location: index.php?page=all-student');
     }

  }

?>
<div class="row">
    <div class="col-sm-6">
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Student Name</label>
                <input class="form-control" type="text" name="name" id="name" placeholder="Please enter Student name." required='' value= '<?= $db_row["name"]; ?>'>
            </div>
            <div class="form-group">
                <label for="roll">Student Roll</label>
                <input class="form-control" type="text" name="roll" id="roll" placeholder="Please enter Student roll." pattern="[0-9]{4}" required='' value= '<?= $db_row["roll"]; ?>'>
            </div>
            <div class="form-group">
                <label for="city">Student City</label>
                <input class="form-control" type="text" name="city" id="city" placeholder="Please enter Student city." required=''  value= '<?= $db_row["city"]; ?>'>
            </div>
            <div class="form-group">
                <label for="contact">P-contact</label>
                <input class="form-control" type="text" name="contact" id="contact" placeholder="01***********" pattern="01[1|3|4|6|7|8|9][0-9]{8}" required=''  value= '<?= $db_row["contact"]; ?>'>
            </div>
            <div class="form-group">
                <label for="class">Student Class</label>
                <select name="class" id="class" class="form-control" required='' >
                    <option value="">select</option>
                    <option value="1st">1st</option>
                    <option value="2nd">2nd</option>
                    <option value="3rd">3rd</option>
                    <option value="4th">4th</option>
                    <option value="5th">5th</option>
                </select>
            </div><br>
            <div class="form-group">
                <input class="btn btn-info pull-right" type="submit" value="Update Student" name="update-student" >
            </div><br>
        </form>
    </div>
</div>