
<div class="content">
    <h1><span class="text-primary" style="font-size:60px"> <i class="fas fa-address-card"></i> Usar Profile. </span></h1>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-address-card"></i> My profile.</li>
        </ol>
 <?php
 $session_user =  $_SESSION['user_login'];
 
 $user_data = mysqli_query($link, "SELECT * FROM `users` WHERE `username` = '$session_user'");
$user_row = mysqli_fetch_assoc($user_data);
 ?>

<div class="row">
    <div class="col-sm-6">
        <table class="table table-bordered">
            <tr>
                <td>User Id</td>
                <td><?php echo $user_row['id']; ?></td>
            </tr>
            <tr>
                <td>Name</td>
                <td><?php echo ucwords($user_row['name']); ?></td>
            </tr>
            <tr>
                <td>Username</td>
                <td><?php echo $user_row['username']; ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo $user_row['email']; ?></td>
            </tr>
            <tr>
                <td>stutas</td>
                <td><?php echo ucwords($user_row['stutas']); ?></td>
            </tr>
        </table>
        <a href="user-edit.php?id=$session_user" class="btn-sm btn-info ">Edit Profile</a>
    </div>
    <div class="col-sm-6">
        <a href="">
            <img width="250px" src="images/<?php echo $user_row['photo']; ?>" alt="">
        </a>
<?php
    if(isset($_POST['upload'])){
       

 $photo = explode('.', $_FILES['pro-pic']['name']) ;
 $photo =end( $photo);
  $photo_name = $session_user.'.'.$photo;

  $upload_img = mysqli_query($link, "UPDATE `users` SET `photo`='$photo_name' WHERE `username` = '$session_user' ");
        if($upload_img){
            move_uploaded_file($_FILES['pro-pic']['tmp_name'],'images/'.$photo_name);
        }
    }
?>

        <form action="" enctype="multipart/form-data" method="post"><br>
            <label for="profile"> profile pic </label>
            <input type="file" name="pro-pic" id="pro-pic" required=''><br>
            <input type="submit" name="upload" value="Upload" class="btn btn-sm btn-info">
        </form>
    </div>
</div>








