<h1><span class="text-primary" style="font-size:60px"> <i class="fas fa-tachometer-alt"></i> Add Student. </span>add new student</h1>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user-plus"></i> Add Student</li>
        </ol>
    </nav>
<?php
    if(isset($_POST['add-student'])){
      $name = $_POST['name'];
      $roll = $_POST['roll'];
      $city = $_POST['city'];
      $contact = $_POST['contact'];
      $class = $_POST['class'];

      $picture = explode('.',$_FILES['picture']['name']);
      $picture_ex = end($picture);
      $picture_name = $roll.'.'.$picture_ex;
   
      $query ="INSERT INTO `student_info`(  `name`, `roll`, `class`, `city`, `contact`, `photo`) VALUES ('$name', '$roll', '$class', '$city', '$contact', '$picture_name')";
      $result = mysqli_query($link, $query);
       if($result){
           echo "<p class='alert alert-success'>success</p>";
          move_uploaded_file($_FILES['picture']['tmp_name'],'student-img/'.$picture_name);
        }else{
            echo "<p class='alert alert-danger'>worng</p>";
        }

    }


?>
<div class="row">
    <div class="col-sm-6">
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Student Name</label>
                <input class="form-control" type="text" name="name" id="name" placeholder="Please enter Student name." required=''>
            </div>
            <div class="form-group">
                <label for="roll">Student Roll</label>
                <input class="form-control" type="text" name="roll" id="roll" placeholder="Please enter Student roll." pattern="[0-9]{4}" required=''>
            </div>
            <div class="form-group">
                <label for="city">Student City</label>
                <input class="form-control" type="text" name="city" id="city" placeholder="Please enter Student city." required=''>
            </div>
            <div class="form-group">
                <label for="contact">P-contact</label>
                <input class="form-control" type="text" name="contact" id="contact" placeholder="01***********" pattern="01[1|3|4|6|7|8|9][0-9]{8}" required=''>
            </div>
            <div class="form-group">
                <label for="class">Student Class</label>
                <select name="class" id="class" class="form-control" required=''>
                    <option value="">select</option>
                    <option value="1st">1st</option>
                    <option value="2nd">2nd</option>
                    <option value="3rd">3rd</option>
                    <option value="4th">4th</option>
                    <option value="5th">5th</option>
                </select>
            </div>
            <div class="form-group">
                <label for="picture">Student Picture</label>
                <input class="form-control" type="file" name="picture" id="picture" required=''>
            </div><br>
            <div class="form-group">
                <input class="btn btn-info pull-right" type="submit" value="Add Student" name="add-student" >
            </div><br>
        </form>
    </div>
</div>