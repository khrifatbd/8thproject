<?php
    session_start();
require_once "dbcon.php";
    if(!isset($_SESSION['user_login'])){
        header('location: login.php');
    }
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- fontawesam -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet">

    <title>SMS || admin</title>

    <style>
        a{text-decoration: none;}
        a:hover{color:#333}
    </style>
  </head>
  <body>
  <br>
  <nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand">SMS</a>
    <form class="d-flex"> 
      <a class=" btn " href=""><i class="fad fa-user"></i>Wellcome : Kh rifat </a>
      <a class=" btn" href=""><i class="fas fa-user-plus"></i> Add user </a>
      <a class=" btn" href="index.php?page=user-profile"><i class="fas fa-user"></i> Profile </a>
      <a class=" btn btn-warning" href="logout.php"><i class="fas fa-power-off">log out</i> </a>
    </form>
  </div>
</nav><br>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3">
            <ul class="list-group">
              <a href="index.php?page=deshbord">  <li class="list-group-item active" aria-current="true"><i class="fas fa-tachometer-alt"></i> Dashboard</li></a>
              <a href="index.php?page=add-student">  <li class="list-group-item"> <i class="fas fa-user-graduate"></i> Add Student</li></a>
              <a href="index.php?page=all-student">  <li class="list-group-item"><i class="fas fa-school"></i> All students</li></a>
              <a href="index.php?page=all-user">  <li class="list-group-item"> <i class="far fa-users"></i> All Users</li></a>
            </ul>
        </div>
        <div class="col-sm-9">
<?php

 
  if(isset($_GET['page'])){
    $page = $_GET['page'].'.php';
  }else{
    $page= 'deshbord.php';
  }
if(file_exists($page)){
  require $page;
}else{
  require '404.php';
}

 ?>

        </div>
    </div>
</div>

<footer class="footer-area">
    <p>Copy right khrifat</p>
</footer>

                               
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>