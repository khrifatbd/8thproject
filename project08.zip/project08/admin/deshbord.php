
<?php
    $count_student = mysqli_query($link, "SELECT * FROM `student_info` ");
    $total_student = mysqli_num_rows($count_student);

    $count_users = mysqli_query($link, "SELECT * FROM `users` ");
    $total_users = mysqli_num_rows($count_users);
    
?>

<div class="content">
    <h1><span class="text-primary" style="font-size:60px"> <i class="fas fa-tachometer-alt"></i> Dashboard </span>Stacic Overview</h1>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-tachometer-alt"></i> Dashboard</li>
        </ol>
        <div class="row">
            <div class="col-md-4">
                <div class="bg-primary"  style="font-size: 50px; color:white; padding:20px">
                    <i class="fad fa-users-class"></i>
                    <div class="text-end"><?php echo $total_student; ?> <span style= "font-size: 20px"> Students </span></div>
                </div>
                <div class="bg-info">
                    <a href="index.php?page=all-student">
                    <span style="color:white; padding:10px">View All Students <i class="fas fa-arrow-alt-circle-right "></i></span>
                    </a>
                </div>
            </div> 
            <div class="col-md-4">
                <div class="bg-primary"  style="font-size: 50px; color:white; padding:20px">
                    <i class="fad fa-users-class"></i>
                    <div class="text-end"><?php echo $total_users; ?>  <span style= "font-size: 20px"> Users </span></div>
                </div>
                <div class="bg-info">
                    <a href="index.php?page=all-user">
                    <span style="color:white; padding:10px">View All Users <i class="fas fa-arrow-alt-circle-right "></i></span>
                    </a>
                </div>
            </div> 
        </div>
        <hr>
        <h3>New Students</h3>
        <div class="table-responsive">
        <table class="table table-hover table-bordered table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Roll</th>
                    <th>City</th>
                    <th>Class</th>
                    <th>Contact</th>
                    <th>Photo</th>
                </tr>
            </thead>
            <tbody>
                <?php
                   $show_student= mysqli_query($link, "SELECT * FROM `student_info`");

                    while($row = mysqli_fetch_assoc($show_student)){
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo ucwords($row['name']); ?> </td>
                    <td><?php echo $row['roll']; ?></td>
                    <td><?php echo ucwords($row['city']); ?></td>
                    <td><?php echo $row['class']; ?></td>
                    <td><?php echo $row['contact']; ?></td>
                    <td><img style="width:100px; height:100px" src="student-img/<?php echo $row['photo']; ?>" alt="profile"></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        </div>
    </nav>
</div>